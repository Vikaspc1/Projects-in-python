
# 📘 Python & Pandas Notes for Data Analysis

## 📌 Overview
This repository contains Python notes and code examples for anyone learning data analysis. 
It covers Python basics, data structures, functions, file handling, and progresses to NumPy and Pandas.

## 📂 Contents
- 01_Python_Basics.py
- 02_Data_Structures.py
- 03_Functions_Loops.py
- 04_File_Handling.py
- 05_Numpy_Introduction.py
- 06_Pandas_Introduction.py
- 07_Pandas_Data_Cleaning.py
- 08_Pandas_Visualization.py

## 🚀 How to Use
1. Clone the repo
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run scripts in order to learn step-by-step.

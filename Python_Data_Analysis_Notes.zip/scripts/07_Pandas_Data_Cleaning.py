
# 07 - Pandas Data Cleaning
import pandas as pd
import numpy as np

data = {
    'Name': ['Alice', 'Bob', np.nan, 'David'],
    'Age': [25, np.nan, 30, 40],
    'Salary': [50000, 60000, 70000, None]
}

df = pd.DataFrame(data)
print("Original DataFrame:\n", df)

df['Name'].fillna("Unknown", inplace=True)
df['Age'].fillna(df['Age'].mean(), inplace=True)
df.dropna(subset=['Salary'], inplace=True)

print("Cleaned DataFrame:\n", df)


# 08 - Pandas Visualization
import pandas as pd
import matplotlib.pyplot as plt

data = {
    'Month': ['Jan', 'Feb', 'Mar', 'Apr'],
    'Revenue': [2000, 3000, 2500, 4000]
}

df = pd.DataFrame(data)
df.plot(x='Month', y='Revenue', kind='bar', title='Monthly Revenue')
plt.show()


# 02 - Data Structures

# Lists
fruits = ["apple", "banana", "cherry"]
fruits.append("mango")
print("Fruits:", fruits)

# Tuples
coordinates = (10, 20)
print("Coordinates:", coordinates)

# Dictionaries
person = {"name": "Vikas", "age": 23}
print("Name:", person["name"])

# Sets
unique_numbers = {1, 2, 2, 3, 4}
print("Unique Numbers:", unique_numbers)

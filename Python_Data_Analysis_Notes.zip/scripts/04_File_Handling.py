
# 04 - File Handling

with open("sample.txt", "w") as f:
    f.write("Hello Data Analyst!")

with open("sample.txt", "r") as f:
    content = f.read()
    print("File Content:", content)

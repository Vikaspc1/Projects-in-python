
# 01 - Python Basics

# Variables & Data Types
name = "Vikas"
age = 23
salary = 55000.50
is_active = True

print("Name:", name)
print("Age:", age)
print("Salary:", salary)
print("Active:", is_active)

# Type Conversion
num_str = "10"
num_int = int(num_str)
print("Converted:", num_int + 5)

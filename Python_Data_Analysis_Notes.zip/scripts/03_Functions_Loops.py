
# 03 - Functions & Loops

def greet(name):
    return f"Hello, {name}!"

print(greet("Vikas"))

for i in range(5):
    print("Number:", i)

count = 0
while count < 3:
    print("Count:", count)
    count += 1
